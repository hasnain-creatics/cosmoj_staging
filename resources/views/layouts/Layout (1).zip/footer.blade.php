			<!--Footer-->
			<footer class="footer">
					<div class="container">
						<div class="row align-items-center flex-row-reverse">
							<div class="col-md-12 col-sm-12 text-center">
								Copyright © 2016 - {{date('Y')}} Cosmoj's CRM. All rights reserved
							</div>
						</div>
					</div>
				</footer>
				<!-- End Footer-->
				
	<div id="all-modals">

	</div>

